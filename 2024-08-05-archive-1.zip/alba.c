/**************************************************************************
Pontificia universidad javeriana
autor: juan alba
Fecha: 23/07/24
Materia: SO
**************************************************************************/
#include<stdio.h>
int main(int argc, char *argv[]){
    printf("Hola Mundo...\n");
    printf("\t\t es la clase de SO....\n");
    return(0);
}
