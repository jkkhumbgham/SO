/**************************************************************************
Pontificia universidad javeriana
autor: juan alba
Fecha: 23/07/24
Materia: SO
Tema: progamacion en C
Requerimientos:
        
**************************************************************************/
#include<stdio.h>
/*Funcion bienvenida*/
int main(int argc, char *argv[]){
    printf("ha ingresado [%d]: \n\n",argc);
  printf("ha ingresado la edad:%s;",argv[1]);
  printf("ha ingresado el mes:%s\n;",argv[2]);
  printf("\n");
    return(0);
  
}
